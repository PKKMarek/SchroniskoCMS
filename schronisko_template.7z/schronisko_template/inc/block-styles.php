<?php
/**
 * Block Styles
 *
 * @link https://developer.wordpress.org/reference/functions/register_block_style/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since schronisko 1.0
 */

if ( function_exists( 'register_block_style' ) ) {
	/**
	 * Register block styles.
	 *
	 * @since schronisko 1.0
	 *
	 * @return void
	 */
	function twenty_twenty_one_register_block_styles() {
		// Columns: Overlap.
		register_block_style(
			'core/columns',
			array(
				'name'  => 'schronisko_template-columns-overlap',
				'label' => esc_html__( 'Overlap', 'schronisko_template' ),
			)
		);

		// Cover: Borders.
		register_block_style(
			'core/cover',
			array(
				'name'  => 'schronisko_template-border',
				'label' => esc_html__( 'Borders', 'schronisko_template' ),
			)
		);

		// Group: Borders.
		register_block_style(
			'core/group',
			array(
				'name'  => 'schronisko_template-border',
				'label' => esc_html__( 'Borders', 'schronisko_template' ),
			)
		);

		// Image: Borders.
		register_block_style(
			'core/image',
			array(
				'name'  => 'schronisko_template-border',
				'label' => esc_html__( 'Borders', 'schronisko_template' ),
			)
		);

		// Image: Frame.
		register_block_style(
			'core/image',
			array(
				'name'  => 'schronisko_template-image-frame',
				'label' => esc_html__( 'Frame', 'schronisko_template' ),
			)
		);

		// Latest Posts: Dividers.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'schronisko_template-latest-posts-dividers',
				'label' => esc_html__( 'Dividers', 'schronisko_template' ),
			)
		);

		// Latest Posts: Borders.
		register_block_style(
			'core/latest-posts',
			array(
				'name'  => 'schronisko_template-latest-posts-borders',
				'label' => esc_html__( 'Borders', 'schronisko_template' ),
			)
		);

		// Media & Text: Borders.
		register_block_style(
			'core/media-text',
			array(
				'name'  => 'schronisko_template-border',
				'label' => esc_html__( 'Borders', 'schronisko_template' ),
			)
		);

		// Separator: Thick.
		register_block_style(
			'core/separator',
			array(
				'name'  => 'schronisko_template-separator-thick',
				'label' => esc_html__( 'Thick', 'schronisko_template' ),
			)
		);

		// Social icons: Dark gray color.
		register_block_style(
			'core/social-links',
			array(
				'name'  => 'schronisko_template-social-icons-color',
				'label' => esc_html__( 'Dark gray', 'schronisko_template' ),
			)
		);
	}
	add_action( 'init', 'twenty_twenty_one_register_block_styles' );
}
